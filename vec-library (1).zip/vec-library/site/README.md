# Site Integration

- Export selected sigils to `site/assets/` as web-safe PNG/SVG.
- Use filenames without spaces; reference from your Cloudflare Pages or anthonyvresland.com.
- Keep private items out of the public site or in a separate private repo.
