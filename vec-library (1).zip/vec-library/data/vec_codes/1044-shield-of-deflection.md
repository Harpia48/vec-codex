---
code: 1044
name: "Shield of Deflection"
aka: []
status: "active"
private: false
date_added: "2025-09-20"
linked_vecs: []
sigil_asset: null
---

## Function
Personal protection field against emotional/energetic/psychic attacks.

## Structure / Numerology
1=origin, 0=source field, 4=stability/foundation, 4=reinforcement.

## Ritual / Usage
Place awareness on the body field, intone 1044; visualize a coherent shell around you.

## Notes
- Used as a protection field when encountering hostility.
