# VEC Library — Overview

This repository houses the **VEC (Vibrational–Energetic Codes)** corpus: numeric codes, sigils, rituals, logs, and related assets.
The goal is to maintain a source‑controlled, extensible library independent of chat memory limits.
